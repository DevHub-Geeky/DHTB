require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import 'android.support.*'
import "com.androlua.LuaAdapter"
import "org.w3c.dom.Text"
import "android.view.WindowManager"
import "android.widget.TextView"
import "com.androlua.LuaAdapter"
import "android.widget.ImageView"
import "android.widget.ListView"
import "android.support.v7.widget.*"
import "android.widget.GridLayout"
import "android.support.v4.app.*"
import "com.tencent.smtt.sdk.*"
import "android.widget.PopupMenu"
if Build.VERSION.SDK_INT >= 21 then
  activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS).setStatusBarColor(0xff4285f4);
end
--这个需要系统SDK19以上才能用
if Build.VERSION.SDK_INT >= 19 then
  activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
end
activity.getWindow().setNavigationBarColor(0x009688)
esc=0
function onKeyDown(key,event)
  if(key==4)then
    esc=esc+1
    if esc==5000 then
     else
      task(500,function()
        esc=0
      end)
    end
    return true
  end
end

fltBtncolor='#607D8B'--悬浮窗颜色
fltBtncolor2='#efefef'--悬浮窗图标颜色

color1='#E64A19'--页面一背景颜色
image1='a.png'--页面一图片路径
title1=''--页面一标题文字
text1="DHTB极致简约  3.0.0"--页面一说明文字
textcolor1='#FF000000'--页面一文字颜色
--下面的同上



color2='#00000000'
image2='b.png'
title2=''
text2="简约风格，内容丰富!"
textcolor2='#FF000000'


color3='#00000000'
image3='c.png'
title3=''
text3="图片取色，更多功能等你解锁！"
textcolor3="#FF000000"

color4='#004A19'
image4='d.png'
title4=''
text4="极速体验，现在开始！"
textcolor4="#FF000000"


local viewlayout={
  RelativeLayout,
  layout_height="fill",
  layout_width="fill",
  background="sz2.jpg";
  {
    LinearLayout,
    id='back',
    orientation="vertical",
    layout_width="match_parent",
    layout_height="match_parent",
    {
      PageView,
      layout_width="match_parent",
      id="hd",
      layout_height="match_parent",
      pages={
        {
          RelativeLayout,
      --    background="sz.jpg";
          layout_width="match_parent",
          layout_height="match_parent",
          {
            ImageView,
            id='image1',
            elevation='2dp',
            layout_centerInParent="true",
            background='#',
            src=image1,
            layout_width="65%w",
            layout_height="115.55%w",
          },
          {
            TextView,
            layout_above="image1",
            textSize='30sp',
            textColor=textcolor1,
            text=title1,
            gravity='center',
            layout_width='match_parent',
            layout_height="wrap_content",
            padding='10sp',
          },
          {
            TextView,
            layout_below="image1",
            --textSize='30sp',
            textColor=textcolor1,
            Alpha='0.87',
            text=text1,
            gravity='center',
            layout_width='match_parent',
            layout_height="wrap_content",
            padding='5sp',
          },
        },
        {
          RelativeLayout,
          --background=color2,
          layout_width="match_parent",
          layout_height="match_parent",
          {
            ImageView,
            id='image2',
            elevation='2dp',
            layout_centerInParent="true",
            background='#',
            src=image2,
            layout_width="65%w",
            layout_height="115.55%w",
          },
          {
            TextView,
            layout_above="image2",
            textSize='30sp',
            textColor=textcolor2,
            text=title2,
            gravity='center',
            layout_width='match_parent',
            layout_height="wrap_content",
            padding='10sp',
          },
          {
            TextView,
            layout_below="image2",
            --textSize='30sp',
            textColor=textcolor2,
            Alpha='0.87',
            text=text2,
            gravity='center',
            layout_width='match_parent',
            layout_height="wrap_content",
            padding='5sp',
          },
        },

        {
          RelativeLayout,
         -- background=color3,
          layout_width="match_parent",
          layout_height="match_parent",
          {
            ImageView,
            id='image3',
            elevation='2dp',
            layout_centerInParent="true",
            background='#',
            src=image3,
            layout_width="65%w",
            layout_height="115.55%w",
          },
          {
            TextView,
            layout_above="image3",
            textSize='30sp',
            textColor=textcolor3,
            text=title3,
            gravity='center',
            layout_width='match_parent',
            layout_height="wrap_content",
            padding='10sp',
          },
          {
            TextView,
            layout_below="image3",
            --textSize='30sp',
            textColor=textcolor3,
            Alpha='0.87',
            text=text3,
            gravity='center',
            layout_width='match_parent',
            layout_height="wrap_content",
            padding='5sp',
          },
        },

        {
          RelativeLayout,
       --   background=color4,
          layout_width="match_parent",
          layout_height="match_parent",
          {
            ImageView,
            id='image4',
            elevation='2dp',
            layout_centerInParent="true",
            background='#',
            src=image4,
            layout_width="65%w",
            layout_height="115.55%w",
          },
          {
            TextView,
            layout_above="image4",
            textSize='30sp',
            textColor=textcolor4,
            text=title4,
            gravity='center',
            layout_width='match_parent',
            layout_height="wrap_content",
            padding='10sp',
          },
          {
            TextView,
            layout_below="image4",
            --textSize='30sp',
            textColor=textcolor4,
            Alpha='0.87',
            text=text4,
            gravity='center',
            layout_width='match_parent',
            layout_height="wrap_content",
            padding='5sp',
          },
        },
      },
    },
  },
  {
    LinearLayout,
    id='tt',
    layout_height="56dp",
    background="#00000000",
    layout_centerHorizontal="true",
    layout_alignBottom="back",
    layout_width="match_parent",
    layout_height="70dp",
    gravity='center',
    {
      LinearLayout;
      layout_width="12.5%w";
      background="#50000000",
      {
        TextView;
        layout_width="3.125%w";
        layout_height="2dp";
        background="#FFFFFF",
        id="hua",
      },
    },
  },
  
  
{
CardView,--卡片框控件
id="button",
layout_alignRight="tt",
layout_alignTop="tt",
layout_marginRight="20dp",
 layout_marginTop="-20dp",  
  layout_marginLeft="36%w";      
  layout_marginRight="36%w";   

layout_width="fill",--布局宽度
layout_height="35dp",--布局高度
layout_margin="130dp",--布局边距
elevation="0dp",--阴影层次
cardBackgroundColor="#ffb8d7dc",--卡片背景色
radius="5dp",--圆角半径
{
TextView,--纽扣控件
id="imageview",
gravity='center',
background="#FF74BBFF",--布局背景
layout_width="fill",--布局宽度
layout_height="fill",--布局高度
padding="1dp",--布局填充
text="点击退出",--文本内容
textSize="14sp",--文本大小
textColor="#ff000000",--文本颜色
},
},--卡片框控件 结束
 --[[ {
    CardView,
    id='button',
    layout_column='1',
    layout_width='60dp',
    CardElevation="3dp",
    CardBackgroundColor=fltBtncolor,
    layout_height='60dp',
    Radius='30dp',
    layout_alignRight="tt",
    layout_alignTop="tt",
    layout_marginRight="20dp",
    layout_marginTop="-20dp",
    {
      ImageView,
      id='imageview',
      src='right.png',
      ColorFilter=fltBtncolor2,
      layout_width="wrap_content",
      layout_height="wrap_content",
      layout_gravity="center",
      adjustViewBounds='true',
      maxWidth='30dp',
      maxHeight='30dp',
    },
  },
  --[[]]
}


--activity.requestWindowFeature(Window.FEATURE_NO_TITLE)
--activity.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN)
activity.setContentView(loadlayout(viewlayout))


function 波纹(id,颜色)
  import "android.content.res.ColorStateList"
  local attrsArray = {android.R.attr.selectableItemBackgroundBorderless} 
  local typedArray =activity.obtainStyledAttributes(attrsArray) 
  ripple=typedArray.getResourceId(0,0) 
  Pretend=activity.Resources.getDrawable(ripple) 
  Pretend.setColor(ColorStateList(int[0].class{int{}},int{颜色}))
  id.setBackground(Pretend.setColor(ColorStateList(int[0].class{int{}},int{颜色})))
end
波纹(imageview,0x2A2F2F2F)


local pag=0
local ppg=0
hd.addOnPageChangeListener{
  onPageScrolled=function(p,pO,pp)
    pag=p
    ppg=pO
    if pO~=0 then
      hua.setX(activity.getWidth()/32*pO+p*activity.getWidth()/32)
    end
    if (pag==2 and tonumber(pO)>=0.1 or pag==3)then
      imageview.Text="进入"
    else
      imageview.Text="下一步"
    end
  end,
}
button.onClick=function()
  if (pag==2 and tonumber(ppg)>=0.1 or pag==3)then
    activity.finish()
  end
  hd.showPage(pag+1)
  pag=pag+1
end






