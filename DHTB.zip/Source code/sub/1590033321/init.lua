template="tool"
name="五子棋"
