name="颜色-选色器"
template="tool"
