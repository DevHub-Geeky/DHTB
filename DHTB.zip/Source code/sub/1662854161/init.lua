template="tool"
name="图片-取色器"
