function SensorListener()
  AccelerListener=SensorEventListener({
  onSensorChanged=function(event)
    values = event.values;
    x=values[0]
    y=values[1]
    z=values[2]
    --手机运动幅度
    if (math.abs(x)>12 or math.abs(y)>12 or math.abs(z)>12) then
      if b then
        a=a+1
        numview.setText(tostring(a))
        b=false
        task(600,function()b=true end)
      end
      isShake = false;
    end
  end,
  --传感器精度发生变化
  onAccuracyChanged=function(sensor,accuracy)
  end
})
end

function waline(内容,行,模式)
  file,err=io.open(路径)
  if err==nil then
    a={}
    n=0
    for v,s in io.lines(路径) do
      n=n+1
      table.insert(a,v)
    end
    if 模式==0 then
      table.remove(a,行)
      table.insert(a,行,内容)
     elseif 模式==1 then
      内容=a[行]..内容
      table.remove(a,行)
      table.insert(a,行,内容)
     else
      print("无效操作")
      return true
    end
    内容=""
    for v,c in pairs(a) do
      if n==v then
        内容=内容..c
       else
        内容=内容..c.."\n"
      end
    end
    f=File(tostring(File(tostring(路径)).getParentFile())).mkdirs()
    io.open(tostring(路径),"w"):write(tostring(内容)):close()
   else
    print("文件不存在")
  end
end

function raline(模式,行数)
  mLineTable={}
  AllLine=0
  for k,v in io.lines(路径) do
    AllLine=AllLine+1
    table.insert(mLineTable,k)
  end
  if 模式==0 then
    return mLineTable[行数]
   else
    return AllLine
  end
end

function save()
if ntday then
    waline('\n'..today..":"..a,2,1)
   else
    waline(today..":"..a,3,0)
  end
end
