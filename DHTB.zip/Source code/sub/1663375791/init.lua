name="设备"
template="tool"
